# Calculator# (A Calculator made with C#)#

This is a program I wrote during one of my internships while I was learning C# and Visual Studio. It's essentially the basic-mode Windows calculator re-coded from scratch, with a few scientific functions. There are also unit testing available for NUnit, which is great if you want to try manipulating the code and seeing if you break anything ;) (NUnit is downloaded separately of course, find it on Google)

This Calculator program should hopefully be a good reference to use if you want to see how "engine" code is separated from the GUI in a program.


## Terms of Use ##

Free to use in any projects without notifying me, nor is credit needed (though it'd be much appreciated!). Just do not re-distribute it under anyone else's name and be sure to retain the copyright notice in the source!

 
----------

Copyrighted © 2013 by Greg McLeod

GitHub: [https://github.com/cleod9](https://github.com/cleod9)